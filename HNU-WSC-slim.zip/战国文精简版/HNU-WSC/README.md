﻿# 字头清单

一 七 三 上 下 不 且 中 乃 之
乎 九 也 事 二 五 人 仁 以 信
兄 八 六 其 内 則 前 十 又 口
可 右 名 君 善 四 土 地 士 外
多 大 天 夫 女 如 子 孝 小 少
山 左 弗 弟 後 德 心 忠 思 或
所 故 文 於 日 曰 月 有 木 未
正 死 母 民 水 焉 無 父 王 生
百 目 矣 禮 義 者 而 耳 能 臣
自 莫 行 言 足 身 道 金 長 非

# 文件夹结构

```text
HNU-WSC/
├─ README.md
└─ 战国楚简/
    ├─ 一/
    │   ├─ 01.png
    │   ├─ 02.png
    │   ├─ 03.png
    │   ├─ 04.png
    │   └─ 05.png
    ├─ 七/
    │   ├─ 01.png
    │   ├─ 02.png
    │   ├─ 03.png
    │   ├─ 04.png
    │   └─ 05.png
    ├─ 三/
    │   ├─ 01.png
    │   ├─ 02.png
    │   ├─ 03.png
    │   ├─ 04.png
    │   └─ 05.png
    ├─ 上/
    │   ├─ 01.png
    │   ├─ 02.png
    │   ├─ 03.png
    │   ├─ 04.png
    │   └─ 05.png
    ├─ 下/
    │   ├─ 01.png
    │   ├─ 02.png
    │   ├─ 03.png
    │   ├─ 04.png
    │   └─ 05.png
    ├─ 不/
    │   ├─ 01.png
    │   ├─ 02.png
    │   ├─ 03.png
    │   ├─ 04.png
    │   └─ 05.png
    ├─ 且/
    │   ├─ 01.png
    │   ├─ 02.png
    │   ├─ 03.png
    │   ├─ 04.png
    │   └─ 05.png
    ├─ 中/
    │   ├─ 01.png
    │   ├─ 02.png
    │   ├─ 03.png
    │   ├─ 04.png
    │   └─ 05.png
    ├─ 乃/
    │   ├─ 01.png
    │   ├─ 02.png
    │   ├─ 03.png
    │   ├─ 04.png
    │   └─ 05.png
    ├─ 之/
    │   ├─ 01.png
    │   ├─ 02.png
    │   ├─ 03.png
    │   ├─ 04.png
    │   └─ 05.png
    ├─ 乎/
    │   ├─ 01.png
    │   ├─ 02.png
    │   ├─ 03.png
    │   ├─ 04.png
    │   └─ 05.png
    ├─ 九/
    │   ├─ 01.png
    │   ├─ 02.png
    │   ├─ 03.png
    │   ├─ 04.png
    │   └─ 05.png
    ├─ 也/
    │   ├─ 01.png
    │   ├─ 02.png
    │   ├─ 03.png
    │   ├─ 04.png
    │   └─ 05.png
    ├─ 事/
    │   ├─ 01.png
    │   ├─ 02.png
    │   ├─ 03.png
    │   ├─ 04.png
    │   └─ 05.png
    ├─ 二/
    │   ├─ 01.png
    │   ├─ 02.png
    │   ├─ 03.png
    │   ├─ 04.png
    │   └─ 05.png
    ├─ 五/
    │   ├─ 01.png
    │   ├─ 02.png
    │   ├─ 03.png
    │   ├─ 04.png
    │   └─ 05.png
    ├─ 人/
    │   ├─ 01.png
    │   ├─ 02.png
    │   ├─ 03.png
    │   ├─ 04.png
    │   └─ 05.png
    ├─ 仁/
    │   ├─ 01.png
    │   ├─ 02.png
    │   ├─ 03.png
    │   ├─ 04.png
    │   └─ 05.png
    ├─ 以/
    │   ├─ 01.png
    │   ├─ 02.png
    │   ├─ 03.png
    │   ├─ 04.png
    │   └─ 05.png
    ├─ 信/
    │   ├─ 01.png
    │   ├─ 02.png
    │   ├─ 03.png
    │   ├─ 04.png
    │   └─ 05.png
    ├─ 兄/
    │   ├─ 01.png
    │   ├─ 02.png
    │   ├─ 03.png
    │   ├─ 04.png
    │   └─ 05.png
    ├─ 八/
    │   ├─ 01.png
    │   ├─ 02.png
    │   ├─ 03.png
    │   ├─ 04.png
    │   └─ 05.png
    ├─ 六/
    │   ├─ 01.png
    │   ├─ 02.png
    │   ├─ 03.png
    │   ├─ 04.png
    │   └─ 05.png
    ├─ 其/
    │   ├─ 01.png
    │   ├─ 02.png
    │   ├─ 03.png
    │   ├─ 04.png
    │   └─ 05.png
    ├─ 内/
    │   ├─ 01.png
    │   ├─ 02.png
    │   ├─ 03.png
    │   ├─ 04.png
    │   └─ 05.png
    ├─ 則/
    │   ├─ 01.png
    │   ├─ 02.png
    │   ├─ 03.png
    │   ├─ 04.png
    │   └─ 05.png
    ├─ 前/
    │   ├─ 01.png
    │   ├─ 02.png
    │   ├─ 03.png
    │   ├─ 04.png
    │   └─ 05.png
    ├─ 十/
    │   ├─ 01.png
    │   ├─ 02.png
    │   ├─ 03.png
    │   ├─ 04.png
    │   └─ 05.png
    ├─ 又/
    │   ├─ 01.png
    │   ├─ 02.png
    │   ├─ 03.png
    │   ├─ 04.png
    │   └─ 05.png
    ├─ 口/
    │   ├─ 01.png
    │   ├─ 02.png
    │   ├─ 03.png
    │   ├─ 04.png
    │   └─ 05.png
    ├─ 可/
    │   ├─ 01.png
    │   ├─ 02.png
    │   ├─ 03.png
    │   ├─ 04.png
    │   └─ 05.png
    ├─ 右/
    │   ├─ 01.png
    │   ├─ 02.png
    │   ├─ 03.png
    │   ├─ 04.png
    │   └─ 05.png
    ├─ 名/
    │   ├─ 01.png
    │   ├─ 02.png
    │   ├─ 03.png
    │   ├─ 04.png
    │   └─ 05.png
    ├─ 君/
    │   ├─ 01.png
    │   ├─ 02.png
    │   ├─ 03.png
    │   ├─ 04.png
    │   └─ 05.png
    ├─ 善/
    │   ├─ 01.png
    │   ├─ 02.png
    │   ├─ 03.png
    │   ├─ 04.png
    │   └─ 05.png
    ├─ 四/
    │   ├─ 01.png
    │   ├─ 02.png
    │   ├─ 03.png
    │   ├─ 04.png
    │   └─ 05.png
    ├─ 土/
    │   ├─ 01.png
    │   ├─ 02.png
    │   ├─ 03.png
    │   ├─ 04.png
    │   └─ 05.png
    ├─ 地/
    │   ├─ 01.png
    │   ├─ 02.png
    │   ├─ 03.png
    │   ├─ 04.png
    │   └─ 05.png
    ├─ 士/
    │   ├─ 01.png
    │   ├─ 02.png
    │   ├─ 03.png
    │   ├─ 04.png
    │   └─ 05.png
    ├─ 外/
    │   ├─ 01.png
    │   ├─ 02.png
    │   ├─ 03.png
    │   ├─ 04.png
    │   └─ 05.png
    ├─ 多/
    │   ├─ 01.png
    │   ├─ 02.png
    │   ├─ 03.png
    │   ├─ 04.png
    │   └─ 05.png
    ├─ 大/
    │   ├─ 01.png
    │   ├─ 02.png
    │   ├─ 03.png
    │   ├─ 04.png
    │   └─ 05.png
    ├─ 天/
    │   ├─ 01.png
    │   ├─ 02.png
    │   ├─ 03.png
    │   ├─ 04.png
    │   └─ 05.png
    ├─ 夫/
    │   ├─ 01.png
    │   ├─ 02.png
    │   ├─ 03.png
    │   ├─ 04.png
    │   └─ 05.png
    ├─ 女/
    │   ├─ 01.png
    │   ├─ 02.png
    │   ├─ 03.png
    │   ├─ 04.png
    │   └─ 05.png
    ├─ 如/
    │   ├─ 01.png
    │   ├─ 02.png
    │   ├─ 03.png
    │   ├─ 04.png
    │   └─ 05.png
    ├─ 子/
    │   ├─ 01.png
    │   ├─ 02.png
    │   ├─ 03.png
    │   ├─ 04.png
    │   └─ 05.png
    ├─ 孝/
    │   ├─ 01.png
    │   ├─ 02.png
    │   ├─ 03.png
    │   ├─ 04.png
    │   └─ 05.png
    ├─ 小/
    │   ├─ 01.png
    │   ├─ 02.png
    │   ├─ 03.png
    │   ├─ 04.png
    │   └─ 05.png
    ├─ 少/
    │   ├─ 01.png
    │   ├─ 02.png
    │   ├─ 03.png
    │   ├─ 04.png
    │   └─ 05.png
    ├─ 山/
    │   ├─ 01.png
    │   ├─ 02.png
    │   ├─ 03.png
    │   ├─ 04.png
    │   └─ 05.png
    ├─ 左/
    │   ├─ 01.png
    │   ├─ 02.png
    │   ├─ 03.png
    │   ├─ 04.png
    │   └─ 05.png
    ├─ 弗/
    │   ├─ 01.png
    │   ├─ 02.png
    │   ├─ 03.png
    │   ├─ 04.png
    │   └─ 05.png
    ├─ 弟/
    │   ├─ 01.png
    │   ├─ 02.png
    │   ├─ 03.png
    │   ├─ 04.png
    │   └─ 05.png
    ├─ 後/
    │   ├─ 01.png
    │   ├─ 02.png
    │   ├─ 03.png
    │   ├─ 04.png
    │   └─ 05.png
    ├─ 德/
    │   ├─ 01.png
    │   ├─ 02.png
    │   ├─ 03.png
    │   ├─ 04.png
    │   └─ 05.png
    ├─ 心/
    │   ├─ 01.png
    │   ├─ 02.png
    │   ├─ 03.png
    │   ├─ 04.png
    │   └─ 05.png
    ├─ 忠/
    │   ├─ 01.png
    │   ├─ 02.png
    │   ├─ 03.png
    │   ├─ 04.png
    │   └─ 05.png
    ├─ 思/
    │   ├─ 01.png
    │   ├─ 02.png
    │   ├─ 03.png
    │   ├─ 04.png
    │   └─ 05.png
    ├─ 或/
    │   ├─ 01.png
    │   ├─ 02.png
    │   ├─ 03.png
    │   ├─ 04.png
    │   └─ 05.png
    ├─ 所/
    │   ├─ 01.png
    │   ├─ 02.png
    │   ├─ 03.png
    │   ├─ 04.png
    │   └─ 05.png
    ├─ 故/
    │   ├─ 01.png
    │   ├─ 02.png
    │   ├─ 03.png
    │   ├─ 04.png
    │   └─ 05.png
    ├─ 文/
    │   ├─ 01.png
    │   ├─ 02.png
    │   ├─ 03.png
    │   ├─ 04.png
    │   └─ 05.png
    ├─ 於/
    │   ├─ 01.png
    │   ├─ 02.png
    │   ├─ 03.png
    │   ├─ 04.png
    │   └─ 05.png
    ├─ 日/
    │   ├─ 01.png
    │   ├─ 02.png
    │   ├─ 03.png
    │   ├─ 04.png
    │   └─ 05.png
    ├─ 曰/
    │   ├─ 01.png
    │   ├─ 02.png
    │   ├─ 03.png
    │   ├─ 04.png
    │   └─ 05.png
    ├─ 月/
    │   ├─ 01.png
    │   ├─ 02.png
    │   ├─ 03.png
    │   ├─ 04.png
    │   └─ 05.png
    ├─ 有/
    │   ├─ 01.png
    │   ├─ 02.png
    │   ├─ 03.png
    │   ├─ 04.png
    │   └─ 05.png
    ├─ 木/
    │   ├─ 01.png
    │   ├─ 02.png
    │   ├─ 03.png
    │   ├─ 04.png
    │   └─ 05.png
    ├─ 未/
    │   ├─ 01.png
    │   ├─ 02.png
    │   ├─ 03.png
    │   ├─ 04.png
    │   └─ 05.png
    ├─ 正/
    │   ├─ 01.png
    │   ├─ 02.png
    │   ├─ 03.png
    │   ├─ 04.png
    │   └─ 05.png
    ├─ 死/
    │   ├─ 01.png
    │   ├─ 02.png
    │   ├─ 03.png
    │   ├─ 04.png
    │   └─ 05.png
    ├─ 母/
    │   ├─ 01.png
    │   ├─ 02.png
    │   ├─ 03.png
    │   ├─ 04.png
    │   └─ 05.png
    ├─ 民/
    │   ├─ 01.png
    │   ├─ 02.png
    │   ├─ 03.png
    │   ├─ 04.png
    │   └─ 05.png
    ├─ 水/
    │   ├─ 01.png
    │   ├─ 02.png
    │   ├─ 03.png
    │   ├─ 04.png
    │   └─ 05.png
    ├─ 焉/
    │   ├─ 01.png
    │   ├─ 02.png
    │   ├─ 03.png
    │   ├─ 04.png
    │   └─ 05.png
    ├─ 無/
    │   ├─ 01.png
    │   ├─ 02.png
    │   ├─ 03.png
    │   ├─ 04.png
    │   └─ 05.png
    ├─ 父/
    │   ├─ 01.png
    │   ├─ 02.png
    │   ├─ 03.png
    │   ├─ 04.png
    │   └─ 05.png
    ├─ 王/
    │   ├─ 01.png
    │   ├─ 02.png
    │   ├─ 03.png
    │   ├─ 04.png
    │   └─ 05.png
    ├─ 生/
    │   ├─ 01.png
    │   ├─ 02.png
    │   ├─ 03.png
    │   ├─ 04.png
    │   └─ 05.png
    ├─ 百/
    │   ├─ 01.png
    │   ├─ 02.png
    │   ├─ 03.png
    │   ├─ 04.png
    │   └─ 05.png
    ├─ 目/
    │   ├─ 01.png
    │   ├─ 02.png
    │   ├─ 03.png
    │   ├─ 04.png
    │   └─ 05.png
    ├─ 矣/
    │   ├─ 01.png
    │   ├─ 02.png
    │   ├─ 03.png
    │   ├─ 04.png
    │   └─ 05.png
    ├─ 禮/
    │   ├─ 01.png
    │   ├─ 02.png
    │   ├─ 03.png
    │   ├─ 04.png
    │   └─ 05.png
    ├─ 義/
    │   ├─ 01.png
    │   ├─ 02.png
    │   ├─ 03.png
    │   ├─ 04.png
    │   └─ 05.png
    ├─ 者/
    │   ├─ 01.png
    │   ├─ 02.png
    │   ├─ 03.png
    │   ├─ 04.png
    │   └─ 05.png
    ├─ 而/
    │   ├─ 01.png
    │   ├─ 02.png
    │   ├─ 03.png
    │   ├─ 04.png
    │   └─ 05.png
    ├─ 耳/
    │   ├─ 01.png
    │   ├─ 02.png
    │   ├─ 03.png
    │   ├─ 04.png
    │   └─ 05.png
    ├─ 能/
    │   ├─ 01.png
    │   ├─ 02.png
    │   ├─ 03.png
    │   ├─ 04.png
    │   └─ 05.png
    ├─ 臣/
    │   ├─ 01.png
    │   ├─ 02.png
    │   ├─ 03.png
    │   ├─ 04.png
    │   └─ 05.png
    ├─ 自/
    │   ├─ 01.png
    │   ├─ 02.png
    │   ├─ 03.png
    │   ├─ 04.png
    │   └─ 05.png
    ├─ 莫/
    │   ├─ 01.png
    │   ├─ 02.png
    │   ├─ 03.png
    │   ├─ 04.png
    │   └─ 05.png
    ├─ 行/
    │   ├─ 01.png
    │   ├─ 02.png
    │   ├─ 03.png
    │   ├─ 04.png
    │   └─ 05.png
    ├─ 言/
    │   ├─ 01.png
    │   ├─ 02.png
    │   ├─ 03.png
    │   ├─ 04.png
    │   └─ 05.png
    ├─ 足/
    │   ├─ 01.png
    │   ├─ 02.png
    │   ├─ 03.png
    │   ├─ 04.png
    │   └─ 05.png
    ├─ 身/
    │   ├─ 01.png
    │   ├─ 02.png
    │   ├─ 03.png
    │   ├─ 04.png
    │   └─ 05.png
    ├─ 道/
    │   ├─ 01.png
    │   ├─ 02.png
    │   ├─ 03.png
    │   ├─ 04.png
    │   └─ 05.png
    ├─ 金/
    │   ├─ 01.png
    │   ├─ 02.png
    │   ├─ 03.png
    │   ├─ 04.png
    │   └─ 05.png
    ├─ 長/
    │   ├─ 01.png
    │   ├─ 02.png
    │   ├─ 03.png
    │   ├─ 04.png
    │   └─ 05.png
    └─ 非/
        ├─ 01.png
        ├─ 02.png
        ├─ 03.png
        ├─ 04.png
        └─ 05.png
```
