# HNU-WSC-subest

An updated subset of Chu bamboo-slip character images synchronized with the processed full HNU-WSC dataset.

## Dataset summary

| Item | Value |
| --- | --- |
| Character classes | 100 |
| Images per class | 5 |
| Total images | 500 |
| Image format | PNG |
| Image dimensions | 102 pixels wide × 82 pixels high |
| Image channels | Single-channel, 8-bit grayscale |
| Background | White |

The character classes, sample identities and directory hierarchy are retained from the earlier subset. Each image is named `HNUWSC_<character>_<six-digit source sequence>.png`, keeping its source sequence number from the standardized full dataset. Each image is replaced with its corresponding image from the latest standardized full-dataset output.

## Preprocessing

### 1. Background Normalization

The paper background is standardized to white while preserving the grayscale ink information. Background matching is used when adding padding around the character image.

### 2. Denoising and Deblurring

The subset inherits noise reduction and blur mitigation from the cleaned full-dataset version. Faint ink, fragmentary strokes, and the original character structure are retained where present. This synchronization copies the processed images without applying an additional denoising or sharpening pass.

### 3. Border Removal

Page borders, scan edges, and extraneous edge artifacts are removed or reduced during upstream preprocessing. The resulting character images are synchronized into this subset.

### 4. Resolution Standardization

All images use an exact **102 × 82 pixel** canvas. The source image is scaled proportionally using OpenCV `INTER_LANCZOS4`:

```text
scale = min(102 / source_width, 82 / source_height)
```

The resized image is centered on the canvas and padded with the matched background. The character is not stretched or cropped to fit the canvas. Images remain grayscale, with no additional binarization. Integer pixel rounding may produce a one-pixel difference between opposite padding margins.

## Directory structure

```text
HNU-WSC-subest/
├── README.md
├── 图片来源映射.csv
└── HNU-WSC/
    ├── README.md
    └── 战国楚简/
        ├── 一/
        │   ├── HNUWSC_一_000004.png
        │   ├── HNUWSC_一_000005.png
        │   ├── HNUWSC_一_000014.png
        │   ├── HNUWSC_一_000015.png
        │   └── HNUWSC_一_000016.png
        ├── 七/
        │   └── HNUWSC_七_000001.png ... HNUWSC_七_000018.png
        └── ... (100 character folders in total)
```

The image directory structure matches the previous subset. The root README provides the dataset overview for GitHub; the original `HNU-WSC/README.md` location is also retained.

## Synchronization and provenance

The earlier `CHUBS_` source prefix corresponds to the current `HNUWSC_` prefix. Removing fragmented images from the full collection shifted the current numeric source identifiers for 20 selected samples. These identifiers were corrected using the removal list and preprocessing records. All 500 earlier sample identities are retained; no sample was replaced with a different image. Character labels remain unchanged; subset filenames follow the `HNUWSC_<character>_<source sequence>.png` convention and preserve the full-dataset source sequence numbers.

Images are copied byte-for-byte from the latest 102 × 82 standardized outputs derived from the updated full dataset. Each selected upstream image was checked against the full-dataset source SHA-256 record, and its standardized pixels were independently recomputed for verification.

The UTF-8 source mapping file, `图片来源映射.csv`, contains one row per image. It preserves the original material-source labels and archival filenames, updates the current image dimensions and checksums, and retains legacy checksums for traceability.

- `原图片路径`: current source path relative to the standardized full-dataset root.
- `新图片路径`: image path relative to this repository root.
- `源文件SHA256` and `目标文件SHA256`: matching SHA-256 values for the standardized source image and its subset copy.
- `完整版源图片路径` and `完整版源文件SHA256`: identity and checksum of the updated full-dataset image before resolution standardization.
- `旧版源文件SHA256` and `旧版目标文件SHA256`: checksums retained from the earlier release.
- `旧版图片来源路径`: legacy source image identity, relative to the earlier full dataset.
- `上游质检状态` and `上游质检标记`: quality-review status and flags retained from upstream preprocessing.

All 500 subset images were decoded and checked for an exact width of 102 pixels, height of 82 pixels, and a single grayscale channel. Every class contains exactly five images.

## Character classes

```text
一 七 三 上 下 不 且 中 乃 之
乎 九 也 事 二 五 人 仁 以 信
兄 八 六 其 内 則 前 十 又 口
可 右 名 君 善 四 土 地 士 外
多 大 天 夫 女 如 子 孝 小 少
山 左 弗 弟 後 德 心 忠 思 或
所 故 文 於 日 曰 月 有 木 未
正 死 母 民 水 焉 無 父 王 生
百 目 矣 禮 義 者 而 耳 能 臣
自 莫 行 言 足 身 道 金 長 非
```

## Image quality

The images preserve the available scan evidence. Existing faded, blurred, or incomplete strokes may remain. Standardization does not reconstruct missing character details.
